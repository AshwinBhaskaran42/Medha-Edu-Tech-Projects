import sys
sys.path.append('./modules')

from datetime import date, timedelta
from imports import *

library_branches = {}
library_members = {}
waitlist={}


# === Main Menu ===
def library_main():
    while True:
        print("\n====== LIBRARY MANAGEMENT MENU ======")
        print("1. Add Library Branch")
        print("2. Add Books to Branch")
        print("3. Register Member")
        print("4. Issue Book to Member")
        print("5. Return Book from Member")
        print("6. View Member Reading Profile")
        print("7. Track Reading Challenge")
        print("8. Analyze Reading Patterns")
        print("9. Popular Books Report")
        print("10. Exit")
        choice = input("Enter your choice (1–10): ").strip()

        if choice == "1":
            add_library_branches(library_branches)

        elif choice == "2":
            add_books(library_branches)

        elif choice == "3":
            register_members(library_branches, library_members)

        elif choice == "4":
            issue_books(library_members, library_branches, waitlist)

        elif choice == "5":
            return_books(library_members, library_branches, waitlist)

        elif choice == "6":
            member_id = input("Enter Member ID: ").strip()
            view_member_profile(member_id, library_members, library_branches)

        elif choice == "7":
            member_id = input("Enter Member ID: ").strip()
            track_reading_challenge(member_id, library_members)

        elif choice == "8":
            member_id = input("Enter Member ID: ").strip()
            analyze_reading_patterns(member_id, library_members, library_branches)

        elif choice == "9":
            genre = input("Enter Genre (e.g., Fiction): ").strip()
            days = int(input("Enter number of past days (e.g., 30): ").strip())
            generate_popular_books_report(days, genre, library_members, library_branches)

        elif choice == "10":
            print("Exiting the system.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    library_main()